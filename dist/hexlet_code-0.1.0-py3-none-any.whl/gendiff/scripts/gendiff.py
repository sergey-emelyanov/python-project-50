from gendiff.cli import parse_args
from gendiff import generate_diff


def main():
    parse_args()
    generate_diff('file1.json', 'file2.json')


if __name__ == "__main__":
    main()
