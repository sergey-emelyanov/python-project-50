### Hexlet tests and linter status:
[![Actions Status](https://github.com/sergey-emelyanov/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/sergey-emelyanov/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/maintainability)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/test_coverage)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/test_coverage)