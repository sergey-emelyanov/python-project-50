# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Compares two configuration files and shows a difference',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergey-emelyanov/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/sergey-emelyanov/python-project-50/actions) \n[![Maintainability](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/maintainability)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/test_coverage)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/test_coverage)\n\n# DESCRIPTION\n\nThis CLI utility allows you to show changes in json and yaml files.\n\n___\n### :hammer_and_wrench: Languages and Tools :\n- python  ^3.8\n- poetry  ^1.2\n- pyyaml  ^6.0\n\n\n## Installation\n- Clone repository from git \n- make install\n- make build\n- package-install\n\nIf you use macOS or linux you should change pyton to python3 in make file\n\n### Work with non-nested file\n\n[![asciicast](https://asciinema.org/a/XAqhLyNFpppZ243VVPOhJXs6X.svg)](https://asciinema.org/a/XAqhLyNFpppZ243VVPOhJXs6X)\n\n### Work with nested file format stylish\n\n[![asciicast](https://asciinema.org/a/WTsNCMdouovxvvJLf9b0Pikmo.svg)](https://asciinema.org/a/WTsNCMdouovxvvJLf9b0Pikmo)\n\n### Work with nested file format plain\n\n[![asciicast](https://asciinema.org/a/BdLLeQnTqVW7Q8HJfITw66e4C.svg)](https://asciinema.org/a/BdLLeQnTqVW7Q8HJfITw66e4C)\n\n### Work with nested file format json\n\n[![asciicast](https://asciinema.org/a/qIgNX8qCaMyLFtY4TeyrZmGlD.svg)](https://asciinema.org/a/qIgNX8qCaMyLFtY4TeyrZmGlD)',
    'author': 'sergey-emelyanov',
    'author_email': 'emelia35@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
