# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergey-emelyanov/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/sergey-emelyanov/python-project-50/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/maintainability)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/3bfd70fac20d9d4ab12d/test_coverage)](https://codeclimate.com/github/sergey-emelyanov/python-project-50/test_coverage)',
    'author': 'sergey-emelyanov',
    'author_email': 'emelia35@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
